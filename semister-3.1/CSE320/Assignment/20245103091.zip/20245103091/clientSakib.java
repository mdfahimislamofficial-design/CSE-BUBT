package com.cnassignment;

import java.io.*;
import java.net.*;

public class clientSakib {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 5000);
            System.out.println("clientSakib connected to serverCircle");

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new FileWriter("recive.txt"));
            String msg;
            int count = 0;

            while ((msg = in.readLine()) != null) {
                System.out.println(msg);
                writer.write(msg);
                writer.newLine();
                count++;
            }
            writer.write("Total lines received: " + count);
            writer.close();
            socket.close();

        } catch (Exception e) {
            System.out.println("Error in clientSakib: " + e);
        }
    }
}