package com.cnassignment;

import java.io.*;
import java.net.*;

public class serverCircle {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(5000);
            System.out.println("serverCircle started on port 5000...");

            while (true) {
                Socket socket = server.accept();
                System.out.println("serverCircle connected to client");
                BufferedReader file = new BufferedReader(new FileReader("send.txt"));
                StringBuilder data = new StringBuilder();
                String line;

                while ((line = file.readLine()) != null) {
                    data.append(line).append("\n");
                }
                file.close();

                DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                out.writeBytes(data.toString());

                socket.close();
            }
        } catch (Exception e) {
            System.out.println("Error in serverCircle: " + e);
        }
    }
}