package com.serverassignment;

import java.io.*;
import java.net.*;

public class clientM {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 6000);
            System.out.println("clientM connected to serverSam");
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            PrintWriter writer = new PrintWriter(new FileWriter("recive.txt", true));
            String msg;
            while ((msg = in.readLine()) != null) {
                String formatted = "[Mafuz Received] " + msg;
                System.out.println(formatted);
                writer.println(formatted);
            }
            writer.println("----- Session End -----");
            writer.close();
            socket.close();
        } catch (Exception e) {
            System.out.println("Error in clientM: " + e);
        }
    }
}