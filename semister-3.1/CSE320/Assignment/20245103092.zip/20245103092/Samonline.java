package com.serverassignment;

import java.io.*;
import java.net.*;
import java.time.LocalDateTime;

public class Samonline {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(6000);
            System.out.println("Samonline is live on port 6000...");
            while (true) {
                Socket socket = server.accept();
                System.out.println("Client joined Samonline");
                BufferedReader fileReader = new BufferedReader(new FileReader("send.txt"));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                String line;
                while ((line = fileReader.readLine()) != null) {
                    out.println(LocalDateTime.now() + " -> " + line);
                }
                out.println("=== End of Message ===");
                fileReader.close();
                socket.close();
            }
        } catch (Exception e) {
            System.out.println("Error in serverSam: " + e);
        }
    }
}