package com.server;

import java.io.*;
import java.net.*;

public class ClientOG {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 7000);
            System.out.println("Connected to FTP Server");

            BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
            FileOutputStream fos = new FileOutputStream("data_recive.txt");

            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = bis.read(buffer)) > 0) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            socket.close();

            System.out.println("File received and saved as data_recive.txt");

        } catch (Exception e) {
            System.out.println("FTP Client Error: " + e);
        }
    }
}