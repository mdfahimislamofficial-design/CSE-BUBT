package com.server;

import java.io.*;
import java.net.*;

public class Dotnet {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(7000);
            System.out.println("FTP Server is running on port 7000...");
            while (true) {
                Socket socket = server.accept();
                System.out.println("Client connected to FTP Server");

                File file = new File("Data.txt");
                if (!file.exists()) {
                    System.out.println("File not found!");
                    socket.close();
                    continue;
                }

                FileInputStream fis = new FileInputStream(file);
                BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());

                byte[] buffer = new byte[1024];
                int bytesRead;

                while ((bytesRead = fis.read(buffer)) > 0) {
                    bos.write(buffer, 0, bytesRead);
                }

                bos.flush();
                fis.close();
                socket.close();

                System.out.println("File sent successfully!");
            }

        } catch (Exception e) {
            System.out.println("FTP Server Error: " + e);
        }
    }
}