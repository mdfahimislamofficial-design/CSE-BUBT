import java.net.*;
import java.io.*;

public class HttpServer {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(9090);
            System.out.println("HTTP Server started on port 9090..");
            while (true) {
                Socket socket = server.accept();
                System.out.println("Client connected!");
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                BufferedWriter out = new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream()));
                String line;
                while (!(line = in.readLine()).isEmpty()) {
                    System.out.println(line);
                }
                String response = "HTTP/1.1 200 OK\r\n"
                        + "Content-Type: text/html\r\n"
                        + "\r\n"
                        + "<html><body><h1>Hello from Java Server!</h1></body></html>";
                out.write(response);
                out.flush();
                socket.close();
            }
        } catch (Exception e) {
            System.out.println("Server Error: " + e.getMessage());
        }
    }
}