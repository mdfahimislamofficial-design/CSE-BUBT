import java.net.*;
import java.io.*;

public class HttpClient {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 9090);
            System.out.println("Connected to HTTP Server...");
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            out.write("GET / HTTP/1.1\r\n");
            out.write("Host: localhost\r\n");
            out.write("\r\n");
            out.flush();
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            socket.close();
        } catch (Exception e) {
            System.out.println("Client Error: " + e.getMessage());
        }
    }
}