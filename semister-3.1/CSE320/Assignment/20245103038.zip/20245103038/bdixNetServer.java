package com.assignment;

import java.io.*;
import java.net.*;

public class bdixNetServer {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(8000);
            System.out.println("bdix.net server is active on port 8000...");
            while (true) {
                Socket client = server.accept();
                System.out.println("User connected to bdix.net");
                File file = new File("send.txt");
                if (!file.exists()) {
                    System.out.println("Requested file missing!");
                    client.close();
                    continue;
                }
                BufferedInputStream fileInput = new BufferedInputStream(new FileInputStream(file));
                OutputStream out = client.getOutputStream();
                byte[] chunk = new byte[512];
                int size;
                while ((size = fileInput.read(chunk)) != -1) {
                    out.write(chunk, 0, size);
                }
                out.flush();
                fileInput.close();
                client.close();
                System.out.println("Transfer complete via bdix.net");
            }
        } catch (Exception e) {
            System.out.println("bdix.net Server Issue: " + e);
        }
    }
}