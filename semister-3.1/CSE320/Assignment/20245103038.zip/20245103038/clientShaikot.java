package com.assignment;

import java.io.*;
import java.net.*;

public class clientShaikot {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 8000);
            System.out.println("Connected to bdix.net server");
            InputStream in = socket.getInputStream();
            FileOutputStream fileOut = new FileOutputStream("recive.txt");
            byte[] buffer = new byte[512];
            int length;
            while ((length = in.read(buffer)) != -1) {
                fileOut.write(buffer, 0, length);
            }
            fileOut.close();
            socket.close();
            System.out.println("Download finished. File saved as recive.txt");
        } catch (Exception e) {
            System.out.println("ClientShaikot Error: " + e);
        }
    }
}